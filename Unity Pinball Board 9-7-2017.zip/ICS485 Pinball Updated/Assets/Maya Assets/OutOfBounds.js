﻿#pragma strict

var Ball : Transform;

private var startingPos : Vector3;

function Start() 
{
	startingPos = Ball.position;
}

function OnCollisionEnter(_other : Collision) 
{

	if(_other.gameObject.tag == "Ball") 
	{
		Debug.Log("hello");
		_other.rigidbody.velocity = Vector3.zero;
		_other.transform.position = startingPos;
	}

}
