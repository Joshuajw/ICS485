﻿#pragma strict

 function FixedUpdate()
 {
     var currentVelocity = GetComponent.<Rigidbody>().velocity;
  
     if (currentVelocity.y <= 0f) 
         return;
          
     currentVelocity.y = 0f;
          
     GetComponent.<Rigidbody>().velocity = currentVelocity;
 }
